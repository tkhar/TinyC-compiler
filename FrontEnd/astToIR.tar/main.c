#include <stdio.h>

void print (int a) {
	printf("%d\n",a);
}

int read () {
	int a;
	scanf("%d\n",&a);
	return a;
}

int function(int);

int main() {
	printf("%d\n",function(10));
}
