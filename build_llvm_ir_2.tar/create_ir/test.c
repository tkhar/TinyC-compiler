int test(int m, int n){
	int a = 0;
 
	if (m < n){
		a = m;
	}
	else {
		a = n;
	}
	return(a);
}
