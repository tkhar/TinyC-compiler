// Straight line constant propagation
int f(int a){
	int i;
	int j;
	i = 10;
	j = i + 1;
	return 1;
}
