int f(int a){
	int i = 100;
	
	i = i + 1;

	return i+a;
}
