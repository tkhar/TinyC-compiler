int read() {
	return 5;
}

void print(int a) {
	a = a +1;
}

int test(int m, int n){
	int a;
	a = 5;
	return a;
}
