#include<stdio.h>

int test(int, int);

int main(){
	int i = test(10, 20);
	printf("%d\n", i);
	return 0;
}
