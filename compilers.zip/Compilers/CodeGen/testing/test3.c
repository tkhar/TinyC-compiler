extern int read();
extern void print(int);

int f(int a) {
	int i;
	i = -a;
	return i;
}
