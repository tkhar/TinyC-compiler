int f(int a) {
	int b;
	a = 10;
	b = a + 10;
	if (b == 20) {
		b = 1;
	}
	else {
		b = 2;
	}
	return b;
}
