int read(){
	return 10;
}

int test(int m){
	int i = read();
	return(m + i);
}
