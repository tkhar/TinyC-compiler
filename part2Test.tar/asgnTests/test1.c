// Straight line constant propagation
int main(int a){
	int i = 100;
	
	return i+a;
}
