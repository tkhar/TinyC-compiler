#include"codegen.h"

int num_digits(int n){ 
    int j = 0;
    while (n >= 1){ 
        n = n / 10; 
        j = j + 1;
    }   
    return j;
}

LLVMModuleRef createLLVMModel(char * filename){
	char *err = 0;

	LLVMMemoryBufferRef ll_f = 0;
	LLVMModuleRef m = 0;

	LLVMCreateMemoryBufferWithContentsOfFile(filename, &ll_f, &err);

	if (err != NULL) { 
		return NULL;
	}
	
	LLVMParseIRInContext(LLVMGetGlobalContext(), ll_f, &m, &err);
	return m;
}

void printDirectives(LLVMValueRef func){
	const char* funcName = LLVMGetValueName(func);	
	printf("\t.globl %s\n", funcName);
	printf("\t.type %s, @function\n", funcName);
	printf("%s:\n",funcName);
	printf("\tpushl %%ebp\n");
	printf("\tmovl %%esp, %%ebp\n");
	
}

void printFunctionEnd(){
	printf("\tmovl %%ebp, %%esp\n");
	printf("\tpopl %%ebp\n");
	printf("\tret\n");
}

//Go over all the basic blocks and create the labels
void createBBLabels(LLVMValueRef function){
	int i = 0;
	const char * base = "BB";

	for (LLVMBasicBlockRef basicBlock = LLVMGetFirstBasicBlock(function);
 			 basicBlock;
  			 basicBlock = LLVMGetNextBasicBlock(basicBlock)) {

			char * s = (char *) calloc(num_digits(i) + 3, sizeof(char));
			sprintf(s, "%d", i);
			char * label = (char *) calloc(strlen(base)+strlen(s)+1, sizeof(char));
			strncpy(label, base, 2);
			strcat(label, s);
			
			bb_labels.insert(pair<LLVMBasicBlockRef, char *> (basicBlock, label));
			free(s);
			i = i + 1;
			
	}
	
}

//Populates the map from LLVMValueref (instruction) to index
void create_inst_index(LLVMBasicBlockRef bb){
		int n = 0;
        for (LLVMValueRef instruction = LLVMGetFirstInstruction(bb); instruction;
                                instruction = LLVMGetNextInstruction(instruction)) {
			if (!LLVMIsAAllocaInst(instruction)){
				inst_index.insert(pair<LLVMValueRef, int> (instruction, n));
				n = n + 1;
			}
		}	
}

// Computes the liveness range of each instruction. start is the index of the def and end
// is the index of last use in this basic block.

void compute_liveness(LLVMBasicBlockRef bb){
		
		// Compute the index of all the instructions
		create_inst_index(bb);

        for (LLVMValueRef instruction = LLVMGetFirstInstruction(bb); instruction;
                                instruction = LLVMGetNextInstruction(instruction)) {
			
			// Ignore the alloc instructions
			if (LLVMIsAAllocaInst(instruction)) continue;

			int start, end;
			
			start = inst_index[instruction];
			end = start;
			
			// Compute the last use of the instruction in this basic block
		 
			for (LLVMUseRef u = LLVMGetFirstUse(instruction); u;
					u = LLVMGetNextUse(u)){
				LLVMValueRef user = LLVMGetUser(u);
				
				// Check if use is in the same basic block (this should be the case)
				if (LLVMGetInstructionParent(instruction) == LLVMGetInstructionParent(user)){
					int index = inst_index[user];	
					if (index > end)
							end = index;
				}
				
			}
			
			pair<int, int> range (start, end);
			live_range.insert(pair<LLVMValueRef, pair<int, int>> (instruction, range));
		}

        for (LLVMValueRef instruction = LLVMGetFirstInstruction(bb); instruction;
                                instruction = LLVMGetNextInstruction(instruction)) {

			if (LLVMIsAAllocaInst(instruction)) continue;

			pair<int, int> range = live_range[instruction];
			LLVMDumpValue(instruction);
			printf("\t%d\t%d\n", range.first, range.second);
		}
		
}

void clear_data(){
	inst_index.clear();
	live_range.clear();
	return;
}

void walkBasicblocks(LLVMValueRef function){
	//Go over all the basic blocks and create the labels

	for (LLVMBasicBlockRef basicBlock = LLVMGetFirstBasicBlock(function);
 			 basicBlock;
  			 basicBlock = LLVMGetNextBasicBlock(basicBlock)) {
		compute_liveness(basicBlock);
		clear_data();
	}
}

void walkFunctions(LLVMModuleRef module){
	for (LLVMValueRef function =  LLVMGetFirstFunction(module); 
			function; 
			function = LLVMGetNextFunction(function)) {

		//const char* funcName = LLVMGetValueName(function);	

		
		if (!LLVMIsDeclaration(function)){
			printDirectives(function);
			createBBLabels(function);
			walkBasicblocks(function);
			printFunctionEnd();
		}
 	}
}

int main(int argc, char** argv)
{
	LLVMModuleRef m;

	if (argc == 2){
		m = createLLVMModel(argv[1]);
	}
	else{
		m = NULL;
		return 1;
	}

	if (m != NULL){
		walkFunctions(m);
		//LLVMDumpModule(m);
	}
	else {
	    printf("m is NULL\n");
	}
	
	return 0;
}
