extern int read();
extern void print(int);

int func(int a){
	int i;
	int j;
	j = read();
	i = a + -j;
	print(i);
	return i;
}
