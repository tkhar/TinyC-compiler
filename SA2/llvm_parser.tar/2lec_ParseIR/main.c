#include<stdio.h>

int func1(int a, int b, int n);

int main(){
	printf("%d\n", func1(10, 20, 30));
	return 1;
}
