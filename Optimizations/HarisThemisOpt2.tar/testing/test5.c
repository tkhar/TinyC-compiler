int f(){
	int i = 0; 
	int j;

	j = 100;
	
	while (i < 1000){
		j = 200;
		i = i + 1;
	}
	
	return j;
}
