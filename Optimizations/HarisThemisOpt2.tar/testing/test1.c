// Straight line constant propagation
int f(int a){
	int i = 100;
	
	return i+a;
}
